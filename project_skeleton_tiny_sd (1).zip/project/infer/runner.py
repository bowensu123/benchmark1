import torch, multiprocessing as mp
from .devices import device_for_rank, set_global_seed
from .factory import PipelineFactory
from .ipc import Channels
from .io_utils import load_prompts, ensure_dir
from .algorithms.sequential import SequentialAlgo
from .algorithms.chords import ChordsAlgo

def _algo_from_name(name: str):
    if name == "sequential": return SequentialAlgo()
    if name == "chords": return ChordsAlgo()
    raise NotImplementedError(name)

def _worker_entry(rank, channels_tuple, model_config, algo_config):
    channels = Channels.from_tuple(channels_tuple)
    device_for_rank(rank)
    pipe = PipelineFactory.build(model_config).to(f"cuda:{rank}" if torch.cuda.is_available() else "cpu")
    algo = _algo_from_name(algo_config.algo_name)
    algo.run_worker(pipe, rank=rank, channels=channels, model_config=model_config, algo_config=algo_config)

def run_inference(config):
    set_global_seed(config.model.seed)
    ctx = mp.get_context("spawn")
    channels = Channels(ctx)
    channels_tuple = channels.as_tuple()

    procs = []
    ngpu = max(1, config.ngpu)
    for rank in range(1, ngpu):
        p = ctx.Process(target=_worker_entry, args=(rank, channels_tuple, config.model, config.algo))
        p.start(); procs.append(p)

    device_for_rank(0)
    pipe = PipelineFactory.build(config.model).to("cuda:0" if torch.cuda.is_available() else "cpu")
    algo = _algo_from_name(config.algo.algo_name)

    prompts = load_prompts(config.prompt_file)
    ensure_dir(config.output_base_path)

    algo.run_master(pipe, channels=channels, prompts=prompts, model_config=config.model,
                    algo_config=config.algo, output_dir=config.output_base_path)

    channels.broadcast_shutdown(n=ngpu-1)
    for p in procs: p.join()