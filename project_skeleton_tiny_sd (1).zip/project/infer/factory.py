import types, torch
from diffusers import StableDiffusionPipeline
class PipelineFactory:
    @staticmethod
    def build(model_config):
        name = model_config.model_name
        dtype = torch.float32
        if str(model_config.dtype).lower() == "float16":
            dtype = torch.float16
        elif str(model_config.dtype).lower() == "bfloat16":
            dtype = torch.bfloat16
        if name == "tiny":
            pipe = StableDiffusionPipeline.from_pretrained(model_config.model_path, torch_dtype=dtype)
            from snippets.sd_tiny import forward_chords, forward_chords_worker
            pipe.forward_chords = types.MethodType(forward_chords, pipe)
            pipe.forward_chords_worker = types.MethodType(forward_chords_worker, pipe)
        else:
            raise NotImplementedError(f"Unknown model_name: {name}")
        if hasattr(pipe, "vae"):
            try:
                pipe.vae.enable_slicing(); pipe.vae.enable_tiling()
            except Exception: pass
        return pipe