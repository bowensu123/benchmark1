import torch, random, numpy as np
def set_start_method():
    import torch.multiprocessing as mp
    mp.set_start_method("spawn", force=True)
def set_global_seed(seed: int):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
def device_for_rank(rank: int):
    if torch.cuda.is_available():
        torch.cuda.set_device(rank)
        return f"cuda:{rank}"
    return "cpu"