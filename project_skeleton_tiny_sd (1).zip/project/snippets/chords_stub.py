import torch
from typing import List, Tuple, Dict

class CHORDS:
    def __init__(self, T: int, x0: torch.Tensor, num_cores: int, solver, init_t=None, stopping_kwargs=None, verbose: bool=False):
        self.T = int(T)
        self.x_cur = x0
        self.t_idx = 0
        self.solver = solver
        self.verbose = verbose
        self._hit_x = [x0.clone()]
        self._hit_idx = [0]
        self._hit_time = [0.0]
        self._pending_scores: Dict[int, torch.Tensor] = {}
        self.cur_core_to_compute: List[int] = []

    def get_allocation(self) -> List[Tuple[int, int, torch.Tensor]]:
        if self.t_idx >= self.T: return []
        return [(self.t_idx, 0, self.x_cur)]

    def update_scores(self, scores):
        for t, k, score in scores:
            self._pending_scores[t] = score

    def update_states(self, n: int):
        for _ in range(n):
            score = self._pending_scores.get(self.t_idx, None)
            if score is None:
                raise RuntimeError(f"No score for timestep {self.t_idx}; call update_scores first.")
            x_next = self.solver(self.x_cur, score, self.t_idx, self.t_idx)
            self.x_cur = x_next
            self.t_idx += 1
            self._hit_x.append(self.x_cur.clone().detach())
            self._hit_idx.append(self.t_idx)
            self._hit_time.append(float(self.t_idx))

    def schedule_cores(self):
        return [], self.t_idx >= self.T

    def get_last_x_and_hittime(self):
        return self._hit_idx, self._hit_x, self._hit_time

    def get_flops_count(self) -> int:
        return 0