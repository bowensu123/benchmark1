from .base import Algorithm
from ..io_utils import ensure_dir, safe_name, save_image, save_stats
import torch, os
class ChordsAlgo(Algorithm):
    def run_master(self, pipe, *, channels, prompts, model_config, algo_config, output_dir):
        gen = torch.Generator().manual_seed(model_config.seed)
        for i, prompt in enumerate(prompts):
            cur = os.path.join(output_dir, safe_name(prompt)); ensure_dir(cur)
            images_or_tuple, stats = pipe.forward_chords(
                prompt=prompt, height=model_config.height, width=model_config.width,
                num_images_per_prompt=model_config.num_images_per_prompt,
                num_inference_steps=model_config.num_inference_steps,
                guidance_scale=model_config.guidance_scale, generator=gen,
                mp_queues=(channels.to_workers, channels.to_master, channels.ctrl),
                full_return=algo_config.full_return, num_cores=getattr(algo_config, "num_cores", 2),
                init_t=getattr(algo_config, "init_t", None),
                stopping_kwargs=getattr(algo_config, "stopping_kwargs", None),
                verbose=getattr(algo_config, "verbose", False),
            )
            if algo_config.full_return:
                image_list, _ = images_or_tuple
                for idx, img in enumerate(image_list):
                    img[0].save(os.path.join(cur, f"image_iter{idx}.png"))
            else:
                save_image(images_or_tuple, os.path.join(cur, "image.png"))
            stats = {**stats, "prompt": prompt, "ngpu": getattr(model_config, "ngpu", 1)}
            save_stats(stats, os.path.join(cur, "stats.json"))
    def run_worker(self, pipe, *, rank, channels, model_config, algo_config):
        dev = f"cuda:{rank}" if torch.cuda.is_available() else "cpu"
        if not hasattr(pipe, "forward_chords_worker"):
            raise NotImplementedError("Pipeline lacks forward_chords_worker for chords.")
        pipe.forward_chords_worker(mp_queues=(channels.to_workers, channels.to_master, channels.ctrl), device=dev)