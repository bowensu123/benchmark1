from .base import Algorithm
from ..io_utils import ensure_dir, safe_name, save_image
import torch, os
class SequentialAlgo(Algorithm):
    def run_master(self, pipe, *, channels, prompts, model_config, algo_config, output_dir):
        gen = torch.Generator().manual_seed(model_config.seed)
        for i, prompt in enumerate(prompts):
            out = pipe(height=model_config.height, width=model_config.width, prompt=prompt,
                       num_images_per_prompt=model_config.num_images_per_prompt,
                       num_inference_steps=model_config.num_inference_steps,
                       guidance_scale=model_config.guidance_scale, generator=gen)
            img = out.images[0]
            cur = os.path.join(output_dir, safe_name(prompt)); ensure_dir(cur)
            save_image(img, os.path.join(cur, "image.png"))
    def run_worker(self, *args, **kwargs):
        pass