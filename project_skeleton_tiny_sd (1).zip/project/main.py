import hydra
from infer.devices import set_start_method
from infer.runner import run_inference

@hydra.main(version_base=None, config_path="./configs", config_name="base")
def main(cfg):
    set_start_method()
    run_inference(cfg)

if __name__ == "__main__":
    main()