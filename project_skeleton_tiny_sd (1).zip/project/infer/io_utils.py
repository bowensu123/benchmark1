import os, json
def ensure_dir(path: str): os.makedirs(path, exist_ok=True)
def safe_name(s: str) -> str: return s.replace(" ", "_").replace(".", "_")
def load_prompts(path: str): 
    with open(path, "r") as f: 
        return [ln.strip() for ln in f if ln.strip()]
def save_image(img, path: str):
    if hasattr(img, "save"): img.save(path)
    else:
        from PIL import Image
        Image.fromarray(img).save(path)
def save_stats(d: dict, path: str):
    with open(path, "w") as f: json.dump(d, f, indent=2, ensure_ascii=False)